Pandell Random Number List Generator 1.0 - 06/11/12

This program has been designed to provide you with an inclusive list of random numbers in a range from 1 to 1,000,000.  You will be able to display this list to the screen as well as save it to a file named "PandellRandomNumberList.txt" which will be placed in the same directory as the executable. 

Starting the program will take you to a simple menu on the screen where you can use your keyboard to input your menu choice and then have the program perform the desired action.

You are able to use upper or lower case letters, and if your input is invalid or out of bounds of the range allowed by the program you will be notified and the program should continue to execute and allow you to re-enter new values. 

For any further questions please see the in help menu options or contact Pandell Random Number List Generator support at:

Phone: (555) 123 4567
Email: support@MarkRichardsonInc.com


